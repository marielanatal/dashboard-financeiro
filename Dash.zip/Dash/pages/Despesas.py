import streamlit as st

st.title("📘 Dashboard de Despesas 2024–2025")

st.info("Página criada com sucesso! Agora podemos carregar sua planilha de despesas aqui.")
